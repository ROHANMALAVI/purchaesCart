import React from 'react'

export default function Buy() {
  return (
    <div className='container'>
     <h2> ......  </h2>
     <img  height={700} width={1200}
      src="https://rukminim1.flixcart.com/image/832/832/k69ncsw0/card/r/9/n/60-6010522454483-greeting-for-u-enterprises-original-imafzrgza4bbbhux.jpeg?q=70"
      alt="new"
      />
    </div>
  )
}
